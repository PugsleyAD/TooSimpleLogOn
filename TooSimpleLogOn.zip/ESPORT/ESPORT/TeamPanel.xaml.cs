﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using DataManagement;
using DataManagement.Models;

namespace ESPORT
{
    /// <summary>
    /// Interaction logic for TeamsPanel.xaml
    /// </summary>
    public partial class TeamPanel : UserControl
    {
        // Create our class object for communicating with the database. 
        DataAdapter data = new DataAdapter();
        // A list of Team objects.
        List<Teams> teamList = new List<Teams>();
        //Acts as a flag to indicate which way to save our data, as a new entry or an edit.
        bool isNewEntry = true;

        private RolePasser rolePasser;
        private void DisableButtons(DependencyObject DO)
        {
            DisableButtonsRecursive(DO);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (rolePasser.Role.Equals("VIEWONLY"))
            {
                DisableButtons(this); // Call the method to disable buttons
            }
        }
        private void DisableButtonsRecursive(DependencyObject DO)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(DO); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(DO, i);

                if (child is Button button)
                {
                    button.IsEnabled = false;
                }
                else if (child is DependencyObject dependencyObject)
                {
                    DisableButtonsRecursive(dependencyObject);
                }
            }
        }
        public TeamPanel(RolePasser rolePasser)
        {
            InitializeComponent();
            UpdateDataGrid();
            this.rolePasser = rolePasser;
        }

        private void UpdateDataGrid()
        {
            teamList = data.GetAllTeams();
            dgvTeams.ItemsSource = teamList;
            dgvTeams.Items.Refresh();
        }

        private void ClearDataEntryFields()
        {
            txtId.Text = string.Empty;
            txtTeam.Text = string.Empty;
            txtContact.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPoint.Text = string.Empty;
            //Sets the save flag to new entry mode.
            isNewEntry = true;
        }

        private bool IsFormFilledCorrectly()
        {
            if (String.IsNullOrWhiteSpace(txtTeam.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(txtContact.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(txtPhone.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(txtEmail.Text))
            {
                return false;
            }
            return true;
        }

        private bool IsNameDupicated(string name)
        {
            teamList = data.GetAllTeams();

            foreach (var team in teamList)
            { 
                if(team.Team.Trim().Equals(name))
                { return true; }
            }
            return false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (IsFormFilledCorrectly() == false)
            {
                MessageBox.Show("Please ensure fields are filled corectly.");
                return;
            }

            if (IsNameDupicated(txtTeam.Text.Trim()) && txtId.Text == string.Empty)
            {
                MessageBox.Show("Dupicated Name, please rename.");
                return;
            }

            //Try to convert string in the PointBox to int
  
            bool isNumber = int.TryParse(txtPoint.Text, out int number);

            if (isNumber&&number>=0)
            {
                // Get the Team details from the entry form
                Teams teamEntry = new Teams();
                teamEntry.Team = txtTeam.Text;
                teamEntry.Contact = txtContact.Text;
                teamEntry.Phone = txtPhone.Text;
                teamEntry.Email = txtEmail.Text;
                teamEntry.Points = number;


                //Chooses the desired save mode based upon the state of the isNewEntry flag.
                if (isNewEntry)
                {
                    //Pass the Team details to the database to be added.
                    data.AddNewTeam(teamEntry);
                }
                else
                {
                    // Get the Team Id from the entry form.
                    teamEntry.Id = Convert.ToInt32(txtId.Text);
                    // Pass the Team details to the database to be updated.
                    data.UpdateTeam(teamEntry);
                }

                //Update the on-screen display.
                ClearDataEntryFields();
                UpdateDataGrid();
            }

            else
            {
                MessageBox.Show("Posive number in Competitioin_Points!");
            }
        }



        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearDataEntryFields();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Checks that a vlid row is selected, otherwise it returns out of the method.
            if (dgvTeams.SelectedIndex < 0)
            {
                return;
            }
            //Get the Id of the selected entry from the list.
            int Id = teamList[dgvTeams.SelectedIndex].Id;
            // Open a message box to confirm deleting the selected entry.
            MessageBoxResult response = MessageBox.Show("Are you sure you want to delete this entry?",
                                                            "Delete Confirmation", MessageBoxButton.YesNo);

            List<ResultView> rvList = data.GetAllResults();
            foreach(ResultView r in rvList) 
            { 
                if(txtId.Text == r.Team) 
                {
                    MessageBox.Show("Unable to delect when Team still with results.");
                    return;
                }
                if (txtTeam.Text == r.Team)
                {
                    MessageBox.Show("Unable to delect when Team still with results.");
                    return;
                }
            }

            // If the Team pressed YES, go ahead with deletion.
            if (response == MessageBoxResult.Yes)
            {
                // Send request to delete entry matching provided Id.
                data.DeleteTeam(Id);
                ClearDataEntryFields();
                UpdateDataGrid();
            }
        }

        private void dgvTeams_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Checks that a vlid row is selected, otherwise it returns out of the method.
            if (dgvTeams.SelectedIndex < 0)
            {
                return;
            }
            //Get the Id of the selected entry from the list.
            int Id = teamList[dgvTeams.SelectedIndex].Id;
            //Gets the Team from the database that matches the current Id value. 
            Teams teamEntry = data.GetTeamById(Id);
            //Copy the Team details into the form.
            txtId.Text = teamEntry.Id.ToString();
            txtTeam.Text = teamEntry.Team;
            txtContact.Text = teamEntry.Contact;
            txtPhone.Text = teamEntry.Phone;
            txtEmail.Text = teamEntry.Email;
            txtPoint.Text = teamEntry.Points.ToString();
            //Sets the save flag to edit mode.
            isNewEntry = false;
        }
    }
}
