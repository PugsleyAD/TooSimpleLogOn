﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Dapper;
using DataManagement;
using DataManagement.Models;

namespace ESPORT
{
    /// <summary>
    /// Interaction logic for ResultPanel.xaml
    /// </summary>
    public partial class ResultPanel : UserControl
    {
        //The class object used to communicate with the Database. 
        DataAdapter data = new DataAdapter();

        //Lists used to populate the combo boxes. 
        List<Teams> teamList = new List<Teams>();
        List<Events> eventList = new List<Events>();
        List<Games> gameList = new List<Games>();


        //Lists used to populate the data grid.
        List<ResultView> resultList = new List<ResultView>();

        //flag to indicate the correct save mode (NEW or UPDATE)
        bool isNewEntry = true;

        private RolePasser rolePasser;
        private void DisableButtons(DependencyObject DO)
        {
            DisableButtonsRecursive(DO);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (rolePasser.Role.Equals("VIEWONLY"))
            {
                DisableButtons(this); // Call the method to disable buttons
            }
        }
        private void DisableButtonsRecursive(DependencyObject DO)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(DO); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(DO, i);

                if (child is Button button)
                {
                    button.IsEnabled = false;
                }
                else if (child is DependencyObject dependencyObject)
                {
                    DisableButtonsRecursive(dependencyObject);
                }
            }
        }
        public ResultPanel(RolePasser rolePasser)
        {
            InitializeComponent();
            SetupComboBoxes();
            UpdateDataGrid();
            this.rolePasser = rolePasser;

        }

        public void UpdateDataGrid()
        {
            resultList = data.GetAllResults();
            dgvResults.ItemsSource = resultList;
            dgvResults.Items.Refresh();
        }

        private void SetupComboBoxes()
        {
            //Get the teams/events/games from the database
            teamList = data.GetAllTeams();
            eventList = data.GetAllEvents();
            gameList = data.GetAllGames();

            //Sets the list as the source of the combo box.
            //Sets the Name property of each list item as what displays in the combo box.
            //Sets the value that is returned when a combo box option is selected.
            cboEvent.ItemsSource = eventList;
            cboEvent.DisplayMemberPath = "Event";
            cboEvent.SelectedValuePath = "Id";

            cboGame.ItemsSource = gameList;
            cboGame.DisplayMemberPath = "Game";
            cboGame.SelectedValuePath = "Id";

            cboTeam.ItemsSource = teamList;
            cboTeam.DisplayMemberPath = "Team";
            cboTeam.SelectedValuePath = "Id";

            cboOp.ItemsSource = teamList;
            cboOp.DisplayMemberPath = "Team";
            cboOp.SelectedValuePath = "Id";

        }

        private void ClearDataEntryFields()
        {
            //Set the form text fields to blank.
            txtId.Text = string.Empty;
            //Set the form combo boxes back to no entry selected.
            cboEvent.SelectedIndex = -1;
            cboGame.SelectedIndex = -1;
            cboTeam.SelectedIndex = -1;
            cboOp.SelectedIndex = -1;
            rbWin.IsChecked = false;
            rbLoss.IsChecked = false;
            rbDraw.IsChecked = false;

            isNewEntry = true;
        }

        /// <summary>
        /// Checks all the data fields of the form to see if they hold valid data for saving.
        /// If any field is invalid the method returns false.
        /// </summary>
        /// <returns>Whether the data fields contain valid data.</returns>
        private bool IsFormFilledCorrectly()
        {

            //Checks if the combo box has an option selected and is not still on blank 
            if (cboEvent.SelectedIndex < 0 || cboTeam.SelectedIndex < 0 || cboOp.SelectedIndex < 0 || cboTeam.SelectedIndex == cboOp.SelectedIndex || (rbWin.IsChecked==false&&rbDraw.IsChecked==false))
            {
                return false;
            }

            return true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            //Checks if the form is filled correctly. If not, alert the user and cancel further action.
            if (IsFormFilledCorrectly() == false)
            {
                MessageBox.Show("**Please fill form correctly:\n" +
                                "1. All fields must be filled or selected.\n" +
                                "2. Team and Opposing Team must be different.\n");
                return;
            }
            //Collect all the form data and put it into a data object for saving.
            Results currentResult = new Results();

            try
            {
                if (rbWin.IsChecked == true)
                {
                    currentResult.EventId = (int)cboEvent.SelectedValue;
                    currentResult.GameId = (int)cboGame.SelectedValue;
                    currentResult.TeamId = (int)cboTeam.SelectedValue;
                    currentResult.OpTeamId = (int)cboOp.SelectedValue;
                    currentResult.Result = "Win";
                }
                else
                {
                    currentResult.EventId = (int)cboEvent.SelectedValue;
                    currentResult.GameId = (int)cboGame.SelectedValue;
                    currentResult.TeamId = (int)cboTeam.SelectedValue;
                    currentResult.OpTeamId = (int)cboOp.SelectedValue;
                    currentResult.Result = "Draw";
                }
                //Save the data based upon whether it is new data or an update to an existing record. 
                if (isNewEntry)
                {
                    data.AddNewResult(currentResult);
                }
                else
                {
                    currentResult.Id = Convert.ToInt32(txtId.Text);
                    data.UpdateResult(currentResult);
                }
                //Update UI components to display current datsa state.
                UpdateDataGrid();
                ClearDataEntryFields();

                //Update Points for Team and OpposingTeam

                int teamIdToUpdate = currentResult.TeamId;
                Teams teamToUpdate = data.GetTeamById(teamIdToUpdate);

                int newPonits = CalculatePoints(teamToUpdate.Team);
                data.UpdatePoints(teamIdToUpdate, newPonits);

                //Upate OpposingTeam
                teamIdToUpdate = currentResult.OpTeamId;

                newPonits = CalculatePoints(teamToUpdate.Team);
                data.UpdatePoints(teamIdToUpdate, newPonits);         
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }



        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearDataEntryFields();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Checks that a valid row is selected, otherwise it returns out of the method.
            if (dgvResults.SelectedIndex < 0)
            {
                return;
            }
            //Get the Id of the selected entry from the list.
            int Id = resultList[dgvResults.SelectedIndex].Id;
            // Open a message box to confirm deleting the selected entry.
            MessageBoxResult response = MessageBox.Show("Are you sure you want to delete this entry?",
                                                            "Delete Confirmation", MessageBoxButton.YesNo);
            // If the user pressed YES, go ahead with deletion.
            if (response == MessageBoxResult.Yes)
            {
                // Send request to delete entry matching provided Id.
                data.DeleteResult(Id);
                ClearDataEntryFields();
                UpdateDataGrid();
            }
        }

        private void dgvResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgvResults.SelectedIndex == -1)
            {
                return;
            }
            //Retrieve the Id (primary key) of the selected row in the table.
            int id = resultList[dgvResults.SelectedIndex].Id;
            //Request the record from the database that matches the provided id. 
            Results selectedResult = data.GetResultById(id);
            //Set the text fields in the entry form to the matching properties of the model.
            txtId.Text = selectedResult.Id.ToString();

            //Set the Selected Value of the combo bnoxes to the entries that match the Id values of their matching
            //properties. 
            //NOTE: Don't use the SeletedIndex value in case the Id and row numbers do not match up.
            cboEvent.SelectedValue = selectedResult.EventId;
            cboGame.SelectedValue = selectedResult.GameId;
            cboTeam.SelectedValue = selectedResult.TeamId;
            cboOp.SelectedValue = selectedResult.OpTeamId;

            if (selectedResult.Result.Trim() == "Win")
            {
                rbWin.IsChecked = true;
                rbLoss.IsChecked = true;
                rbDraw.IsChecked = false;
            }
            else
            {
                rbWin.IsChecked = false;
                rbLoss.IsChecked = false;
                rbDraw.IsChecked = true;
            }

            isNewEntry = false;

            SetupComboBoxes();
            UpdateDataGrid();
        }


        public int CalculatePoints(string team)
        {
            teamList = data.GetAllTeams();

            //int basePoints = Convert.ToInt32(data.GetTeamByName(team).Points);
            int adjustPoints = 0;

            List<ResultView> resultList = new List<ResultView>();

            resultList = data.GetAllResults().Where(result => result.Team.Equals(team, StringComparison.OrdinalIgnoreCase)).ToList();

            foreach (var result in resultList)
            {
                if (result.Result.Equals("Win"))
                {
                    adjustPoints += 2;
                }
                else
                {
                    adjustPoints += 1;
                }
            }
            
            return  adjustPoints;
        }

        private void rbWin_Click(object sender, RoutedEventArgs e) 
        {
            rbWin.IsChecked = true;
            rbLoss.IsChecked = true;
            rbDraw.IsChecked = false;
        }

        private void rbLoss_Click(object sender, RoutedEventArgs e)
        {
            rbWin.IsChecked = true;
            rbLoss.IsChecked = true;
            rbDraw.IsChecked = false;
        }

        private void rbDraw_Click(object sender, RoutedEventArgs e) 
        {
            rbWin.IsChecked = false;
            rbLoss.IsChecked = false;
            rbDraw.IsChecked = true;
        }
    }
}
