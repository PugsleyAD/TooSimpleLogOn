﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataManagement;
using DataManagement.Models;

namespace ESPORT
{
    /// <summary>
    /// Interaction logic for EventsPanel.xaml
    /// </summary>
    public partial class EventPanel : UserControl
    {
        // Create our class object for communicating with the database. 
        DataAdapter data = new DataAdapter();
        // A list of Event objects.
        List<Events> eventList = new List<Events>();
        //Acts as a flag to indicate which way to save our data, as a new entry or an edit.
        bool isNewEntry = true;

        private RolePasser rolePasser;
        private void DisableButtons(DependencyObject DO)
        {
            DisableButtonsRecursive(DO);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (rolePasser.Role.Equals("VIEWONLY"))
            {
                DisableButtons(this); // Call the method to disable buttons
            }
        }
        private void DisableButtonsRecursive(DependencyObject DO)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(DO); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(DO, i);

                if (child is Button button)
                {
                    button.IsEnabled = false;
                }
                else if (child is DependencyObject dependencyObject)
                {
                    DisableButtonsRecursive(dependencyObject);
                }
            }
        }
        public EventPanel(RolePasser rolePasser)
        {
            InitializeComponent();
            UpdateDataGrid();
            this.rolePasser = rolePasser;
        }

        private void UpdateDataGrid()
        {
            eventList = data.GetAllEvents();
            dgvEvents.ItemsSource = eventList;
            dgvEvents.Items.Refresh();
        }

        private void ClearDataEntryFields()
        {
            txtId.Text = string.Empty;
            txtEvent.Text = string.Empty;
            txtLocation.Text = string.Empty;
            pkrDate.SelectedDate = DateTime.Today;

            //Sets the save flag to new entry mode.
            isNewEntry = true;
        }

        private bool IsFormFilledCorrectly()
        {
            if (String.IsNullOrWhiteSpace(txtEvent.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(txtLocation.Text))
            {
                return false;
            }

            return true;
        }

        private bool IsNameDupicated(string name)
        {
            eventList = data.GetAllEvents();

            foreach (var eve in eventList)
            {
                if (eve.Event.Trim().Equals(name))
                { return true; }
            }
            return false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (IsFormFilledCorrectly() == false)
            {
                MessageBox.Show("Make sure form fields are filled correctly before trying to save!");
                return;
            }

            if (IsNameDupicated(txtEvent.Text.Trim()) && txtId.Text == string.Empty)
            {
                MessageBox.Show("Dupicated Name, please rename.");
                return;
            }

            // Get the Event details from the entry form
            Events eventEntry = new Events();
            eventEntry.Event = txtEvent.Text;
            eventEntry.Location = txtLocation.Text;
            eventEntry.Date = pkrDate.SelectedDate.Value;


            //Chooses the desired save mode based upon the state of the isNewEntry flag.
            if (isNewEntry)
            {
                //Pass the Event details to the database to be added.
                data.AddNewEvent(eventEntry);
            }
            else
            {
                // Get the Event Id from the entry form.
                eventEntry.Id = Convert.ToInt32(txtId.Text);
                // Pass the Event details to the database to be updated.
                data.UpdateEvent(eventEntry);
            }

            //Update the on-screen display.
            ClearDataEntryFields();
            UpdateDataGrid();
        }



        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearDataEntryFields();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Checks that a vlid row is selected, otherwise it returns out of the method.
            if (dgvEvents.SelectedIndex < 0)
            {
                return;
            }
            //Get the Id of the selected entry from the list.
            int Id = eventList[dgvEvents.SelectedIndex].Id;
            // Open a message box to confirm deleting the selected entry.
            MessageBoxResult response = MessageBox.Show("Are you sure you want to delete this entry?",
                                                            "Delete Confirmation", MessageBoxButton.YesNo);
            // If the Event pressed YES, go ahead with deletion.
            if (response == MessageBoxResult.Yes)
            {

                List<ResultView> rvList = data.GetAllResults();
                foreach (ResultView r in rvList)
                {
                    if (txtEvent.Text == r.Event)
                    {
                        MessageBox.Show("Unable to delect when Event still with results.");
                        return;
                    }

                }
                // Send request to delete entry matching provided Id.
                data.DeleteEvent(Id);
                ClearDataEntryFields();
                UpdateDataGrid();
            }
        }

        private void dgvEvents_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Checks that a vlid row is selected, otherwise it returns out of the method.
            if (dgvEvents.SelectedIndex < 0)
            {
                return;
            }
            //Get the Id of the selected entry from the list.
            int Id = eventList[dgvEvents.SelectedIndex].Id;
            //Gets the Event from the database that matches the current Id value. 
            Events eventEntry = data.GetEventById(Id);
            //Copy the Event details into the form.
            txtId.Text = eventEntry.Id.ToString();
            txtEvent.Text = eventEntry.Event;
            txtLocation.Text = eventEntry.Location;
            pkrDate.SelectedDate = eventEntry.Date;

            //Sets the save flag to edit mode.
            isNewEntry = false;
        }
    }
}