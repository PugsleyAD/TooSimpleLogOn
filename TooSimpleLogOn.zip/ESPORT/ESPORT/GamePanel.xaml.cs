﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataManagement;
using DataManagement.Models;

namespace ESPORT
{
    /// <summary>
    /// Interaction logic for GamePanel.xaml
    /// </summary>
    public partial class GamePanel : UserControl
    {
        //The class object used to communicate with the Database. 
        DataAdapter data = new DataAdapter();

        //Lists used to populate the combo boxes.
        List<Games> gameList = new List<Games>();


        //Acts as a flag to indicate the correct save mode (NEW or UPDATE)
        bool isNewEntry = true;

        private RolePasser rolePasser;
        private void DisableButtons(DependencyObject DO)
        {
            DisableButtonsRecursive(DO);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (rolePasser.Role.Equals("VIEWONLY"))
            {
                DisableButtons(this); // Call the method to disable buttons
            }
        }
        private void DisableButtonsRecursive(DependencyObject DO)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(DO); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(DO, i);

                if (child is Button button)
                {
                    button.IsEnabled = false;
                }
                else if (child is DependencyObject dependencyObject)
                {
                    DisableButtonsRecursive(dependencyObject);
                }
            }
        }
        public GamePanel(RolePasser rolePasser)
        {
            InitializeComponent();
            SetupComboBoxes();
            UpdateDataGrid();
            this.rolePasser = rolePasser;
        }

        private void UpdateDataGrid()
        {
            gameList = data.GetAllGames();
            dgvGames.ItemsSource = gameList;
            dgvGames.Items.Refresh();
        }

        private void SetupComboBoxes()
        {
            //Sets the list as the source of the combo box. 
            cboType.Items.Add("Team");
            cboType.Items.Add("Solo");
        }

        private void ClearDataEntryFields()
        {
            //Set the form text fields to blank.
            txtId.Text = string.Empty;
            txtGame.Text = string.Empty;
            //Set the form combo boxes back to no entry selected.
            cboType.SelectedIndex = -1;

            isNewEntry = true;
        }

        /// <summary>
        /// Checks all the data fields of the form to see if they hold valid data for saving.
        /// If any field is invalid the method returns false.
        /// </summary>
        /// <returns>Whether the data fields contain valid data.</returns>
        private bool IsFormFilledCorrectly()
        {
            //Check if the price field holds a valid decimal number.
            if (String.IsNullOrWhiteSpace(txtGame.Text))
            {
                return false;
            }
            //Checks if the combo box has an option selected and is not still on blank 
            if (cboType.SelectedIndex < 0)
            {
                return false;
            }

            return true;
        }

        private bool IsNameDupicated(string name)
        {
            gameList = data.GetAllGames();

            foreach (var game in gameList)
            {
                if (game.Game.Trim().Equals(name))
                { return true; }
            }
            return false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            //Checks if the form is filled correctly. If not, alert the user and cancel further action.
            if (IsFormFilledCorrectly() == false)
            {
                MessageBox.Show("Please fill form correctly before saving.\n " +
                                "*All fields must be filled/selected.\n");
                return;
            }

            if (IsNameDupicated(txtGame.Text.Trim()) && txtId.Text == string.Empty)
            {
                MessageBox.Show("Dupicated Name, please rename.");
                return;
            }

            //Collect all the form data and put it into a data object for saving.
            Games currentGame = new Games();
            currentGame.Game = txtGame.Text;
            currentGame.Type = (string)cboType.SelectedValue;
            //Save the data based upon whether it is new data or an update to an existing record. 
            if (isNewEntry)
            {
                data.AddNewGame(currentGame);
            }
            else
            {
                currentGame.Id = Convert.ToInt32(txtId.Text);
                data.UpdateGame(currentGame);
            }
            //Update UI components to display current datsa state.
            UpdateDataGrid();
            ClearDataEntryFields();
        }



        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearDataEntryFields();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Checks that a valid row is selected, otherwise it returns out of the method.
            if (dgvGames.SelectedIndex < 0)
            {
                return;
            }
            //Get the Id of the selected entry from the list.
            int Id = gameList[dgvGames.SelectedIndex].Id;
            // Open a message box to confirm deleting the selected entry.
            MessageBoxResult response = MessageBox.Show("Are you sure you want to delete this entry?",
                                                            "Delete Confirmation", MessageBoxButton.YesNo);
            // If the user pressed YES, go ahead with deletion.
            if (response == MessageBoxResult.Yes)
            {

                List<ResultView> rvList = data.GetAllResults();
                foreach (ResultView r in rvList)
                {
                    if (txtGame.Text ==r.Game)
                    {
                        MessageBox.Show("Unable to delect when Game still with results.");
                        return;
                    }

                }
                // Send request to delete entry matching provided Id.
                data.DeleteGame(Id);
                ClearDataEntryFields();
                UpdateDataGrid();
            }
        }

        private void dgvGames_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgvGames.SelectedIndex == -1)
            {
                return;
            }
            //Retrieve the Id (primary key) of the selected row in the table.
            int Id = gameList[dgvGames.SelectedIndex].Id;
            //Request the record from the database that matches the provided id. 
            Games selectedGame = data.GetGameById(Id);
            //Set the text fields in the entry form to the matching properties of the model.
            txtId.Text = selectedGame.Id.ToString();
            txtGame.Text = selectedGame.Game.ToString();
            //Set the Selected Value of the combo bnoxes to the entries that match the Id values of their matching
            //properties. 
            //NOTE: Don't use the SeletedIndex value in case the Id and row numbers do not match up.
            cboType.SelectedValue = selectedGame.Type;


            isNewEntry = false;
        }
    }
}
