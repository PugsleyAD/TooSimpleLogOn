﻿using DataManagement;
using DataManagement.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ESPORT
{
    /// <summary>
    /// Interaction logic for ReportsPanel.xaml
    /// </summary>
    public partial class ReportP : UserControl
    {
        //Class for managing all our SQL requests form the database for our data models.
        DataAdapter data = new DataAdapter();

        //Lists for managing my Team reports.
        List<Teams> fullTeamList;
        List<Teams> displayTeamList;
        //Lists for managing thr Results reports.
        List<ResultView> fullResultList;
        List<ResultView> displayResultList;

        private RolePasser rolePasser;
        private void DisableButtons(DependencyObject DO)
        {
            DisableButtonsRecursive(DO);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (rolePasser.Role.Equals("VIEWONLY"))
            {
                DisableButtons(this); // Call the method to disable buttons
            }
        }
        private void DisableButtonsRecursive(DependencyObject DO)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(DO); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(DO, i);

                if (child is Button button)
                {
                    button.IsEnabled = false;
                }
                else if (child is DependencyObject dependencyObject)
                {
                    DisableButtonsRecursive(dependencyObject);
                }
            }
        }

        public ReportP(RolePasser rolePasser)
        {
            InitializeComponent();

            //Create an array with the report options for the combobox.
            string[] reportOptions = { "Team Details — Ordered by Competition points", "Team Results — Ordered by Event names", "Team Results — Ordered by Team names" };
            //Assign the array of options to the combobox.
            cboReports.ItemsSource = reportOptions;
            this.rolePasser = rolePasser;
        }

        private List<ResultView> combineList()
        {
            List<ResultView> fullResultList = new List<ResultView>();

            List<ResultView> teamResultList = new List<ResultView>();
            List<ResultView> opResultList = new List<ResultView>();

            List<ResultView> displayResultList = new List<ResultView>();


            fullResultList = data.GetAllResults();

            if (txtSearch.Text.Trim().Length == 0)
            {
                return fullResultList;
            }
            //Combine Win and Loss results for one team
            teamResultList = fullResultList.Where(result => result.Team.Contains(txtSearch.Text, StringComparison.OrdinalIgnoreCase)).ToList();
            opResultList = fullResultList.Where(result => result.OpTeam.Contains(txtSearch.Text, StringComparison.OrdinalIgnoreCase)).ToList();

            foreach (var result in opResultList)
            {
                if (result.Result.Trim() == "Win")
                {
                    result.Result = "Loss";

                    string swop = result.Team;
                    result.Team = result.OpTeam;
                    result.OpTeam = swop;
                }

                if (result.Result.Trim() == "Draw")
                {
                    string swop = result.Team;
                    result.Team = result.OpTeam;
                    result.OpTeam = swop;
                }
            }

            displayResultList = teamResultList.Concat(opResultList).ToList();

            return displayResultList;
        }

        //Triggers when the combobox slecetion is changed.
        private void cboReports_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //If the selected value of the combo box is the blank option, retuyrn out of ther method.
            if (cboReports.SelectedIndex < 0)
            {
                return;
            }
            //Swith on the current selected index of the combobox and run the associated code.
            switch (cboReports.SelectedIndex)
            {
                case 0:
                    //Retrieve all the Teams from the database and order them by name using a LINQ atatement.
                    //NOTE: LINQ is a code based query language used for filetring and sorting collecitons.
                    fullTeamList = data.GetAllTeams().OrderByDescending(team => team.Points).ToList();
                    //Assign the returned list to the display list which will be used in the datagrid and for exporting.
                    displayTeamList = fullTeamList;
                    //Pass the list to the method used for setting the datasource for the datagrid
                    UpdateDataGrid(displayTeamList);
                    break;

                case 1:
                    //Retrieve all the Results from the database and order them by Price using a LINQ atatement.
                    fullResultList = data.GetAllResults().OrderBy(result => result.Event).ToList();
                    //Assign the returned list to the display list which will be used in the datagrid and for exporting.
                    displayResultList = combineList().OrderBy(result => result.Event).ToList();
                    //Pass the list to the method used for setting the datasource for the datagrid

                    UpdateDataGrid(displayResultList);

                    break;

                case 2:
                    //Retrieve all the Results from the database and order them by Category Name using a LINQ atatement.
                    fullResultList = data.GetAllResults().OrderBy(result => result.Team).ToList();
                    //Assign the returned list to the display list which will be used in the datagrid and for exporting.
                    displayResultList = combineList().OrderBy(result => result.Team).ToList();
                    //Pass the list to the method used for setting the datasource for the datagrid

                    UpdateDataGrid(displayResultList);

                    break;
            }
        }

        /// <summary>
        /// Takes a list and then sets it as the itemsource for the datagrid. This method uses Generics (as indicated by the T placeholder)
        /// which takes the provided list and sets T based upon the provided type. 
        /// </summary>
        /// <typeparam name="T">The Type to be used in this method</typeparam>
        /// <param name="displayList">The list to be assigned to the datagrid</param>
        private void UpdateDataGrid<T>(List<T> displayList)
        {
            //Set the provided list as the source of data for the datagrid.
            dgvReports.ItemsSource = displayList;
            //Refresh the datagrid display.
            dgvReports.Items.Refresh();
        }

        //Triggers whenever the text in the search textbox changes
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            //If the current combobox option is the blank entry, return and do nothing. Otherwise, run the correct filter method for the 
            // selected report type.
            if (cboReports.SelectedIndex < 0)
            {
                return;
            }
            else if (cboReports.SelectedIndex == 0)
            {
                FilterTeamReport();
            }
            else
            {
                FilterResultReport();
            }
        }

        private void FilterTeamReport()
        {
            displayTeamList = fullTeamList.Where(team => team.Team.Contains(txtSearch.Text, StringComparison.OrdinalIgnoreCase)).ToList();
            UpdateDataGrid(displayTeamList);
        }

        private void FilterResultReport()
        {
            displayResultList = combineList();
            UpdateDataGrid(displayResultList);
        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {

            if (cboReports.SelectedIndex < 0)
            {
                return;
            }
            else if (cboReports.SelectedIndex == 0)
            {
                ExportToCSV(displayTeamList);
            }
            else
            {
                ExportToCSV(displayResultList);
            }
        }

        private void ExportToCSV<T>(List<T> exportList)
        {
            //Creates the file dialog that lets us select a file location for our data.
            SaveFileDialog dialog = new SaveFileDialog();
            //Sets the filters for the allowewd file types of the dialog.
            dialog.Filter = "Comma-Delimitted-Values|*.csv|" +
                            "Plain Text File|*.txt";
            //Sets the default file location for the dialog to be the MyDocuments folder.
            dialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            //Opens the file dialog from within the if statement and if it is used sucessfully (valid file name and save button pressed)
            //the if statement logic will run.
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(dialog.FileName))
                    {
                        foreach (var item in exportList)
                        {
                            writer.WriteLine(item.ToString());
                        }
                    }
                }
                catch (Exception e) { }
            }
        }

    }
}
