﻿using System.Windows;
using DataManagement;
using DataManagement.Models;

namespace ESPORT
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        DataAdapter data = new DataAdapter();       // Create our class object for communicating with the database

        int incorrectCount;
        public Login()
        {
            InitializeComponent();
        }
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string userName = txtUserName.Text;
            string password = txtPassword.Password;

            Users authenticatedUser = data.GetUser(userName, password);

            if (authenticatedUser.Id == 0 && incorrectCount < 2)
            {
                MessageBox.Show("Incorrect UserName or Password! \n" + $"{2-incorrectCount} more changes left.");
                incorrectCount++;
            }
            else if (authenticatedUser.Id == 0 && incorrectCount == 2)
            {
                //MessageBox.Show("Incorrect UserName or Password! \n" + "You Win 3 more changes!");
                //incorrectCount = 0;
                MessageBox.Show("Incorrect UserName or Password! \n" + "The Application is closing down!");
                this.Close();
            }
            else if (authenticatedUser.Id != 0)
            {
                RolePasser rolePasser = new RolePasser();
                rolePasser.Role = authenticatedUser.Role;
                MainWindow mainWindow = new MainWindow(rolePasser);
                mainWindow.Show();

                Close();
            }
        }
    }
}

