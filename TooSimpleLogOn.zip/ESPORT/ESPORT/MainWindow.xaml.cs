﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;


namespace ESPORT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TeamPanel tp;
        EventPanel ep;
        GamePanel gp;
        ResultPanel rp;
        ReportP rpp;

        private RolePasser rolePasser;

        public MainWindow(RolePasser rolePasser)
        {
            InitializeComponent();
            this.rolePasser = rolePasser;

            tp = new TeamPanel(rolePasser);
            ep = new EventPanel(rolePasser);
            gp = new GamePanel(rolePasser);
            rp = new ResultPanel(rolePasser);
            rpp = new ReportP(rolePasser);
            conMain.Content = tp;

            if (this.rolePasser.Role == "ADMIN")
            {
                MessageBox.Show("Welcome ADMIN, deal with the DataBase Gently.");
            }
            else if (this.rolePasser.Role == "VIEWONLY")
            {
                MessageBox.Show("Welcome mate, enjoy your views!");
            }
        }


        private void btnTeams_Click(object sender, RoutedEventArgs e)
        {
            conMain.Content = tp;
        }

        private void btnEvents_Click(object sender, RoutedEventArgs e)
        {
            conMain.Content = ep;
        }

        private void btnGames_Click(object sender, RoutedEventArgs e)
        {
            conMain.Content = gp;
        }

        private void btnResults_Click(object sender, RoutedEventArgs e)
        {
            conMain.Content = rp;
        }

        private void btnReports_Click(object sender, RoutedEventArgs e)
        {
            conMain.Content = rpp;
        }
    }
}
