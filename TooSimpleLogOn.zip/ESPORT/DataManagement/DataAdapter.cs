﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;
using DataManagement.Models;

namespace DataManagement
{
    public class DataAdapter
    {
        public Users GetUser (string userName, string password)
        {
            string query = "SELECT * FROM Users WHERE UserName = @userName AND Password = @password";

            using (var connection = Helper.CreateSQLServerConnection("Default")) {
                try
                {
                    Users authenticatedUse = connection.QuerySingle<Users>(query, new { userName, password });
                    return authenticatedUse;
                }
                catch (Exception ex) 
                {
                    return new Users();
                }
            }
        }

        public void AddUser(Users userEntry)
        {
            string query = "INSERT INTO Users (UserName, Password, Role) " +
                           "VALUES (@UserName, @Password, @Role)";

            // a using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, userEntry);
            }
        }

        #region Teams
        public Teams GetTeamByName(string team)
        {
            //The SQL Query to be sent to the database with request
            string query = $"SELECT * FROM Teams WHERE Team = {team}";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.QuerySingle<Teams>(query);
            }
        }

        public List<Teams> GetAllTeams()
        {
            //The SQL Query to be sent to the database with request
            string query = "SELECT * FROM Teams";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.Query<Teams>(query).ToList();
            }
        }

        public Teams GetTeamById(int id)
        {
            //The SQL Query to be sent to the database with request
            string query = $"SELECT * FROM Teams WHERE Id = {id}";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.QuerySingle<Teams>(query);
            }
        }

        public void AddNewTeam(Teams teamEntry)
        {
            string query = "INSERT INTO Teams (Team, Contact, Phone, Email, Points) " +
                           "VALUES (@Team, @Contact, @Phone, @Email, @Points)";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, teamEntry);
            }
        }

        public void UpdateTeam(Teams teamEntry)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "UPDATE Teams " +
                           "SET Team=@Team, Contact=@Contact, Phone=@Phone, Email=@Email, Points=@Points " +
                           "WHERE Id=@Id";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, teamEntry);
            }
        }

        public void DeleteTeam(int id)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "DELETE FROM Teams " +
                          $"WHERE Id = {id}";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query);
            }
        }

        #endregion

        #region Events

        public List<Events> GetAllEvents()
        {
            //The SQL Query to be sent to the database with request
            string query = "SELECT * FROM Events";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.Query<Events>(query).ToList();
            }
        }


        public Events GetEventById(int id)
        {
            //The SQL Query to be sent to the database with request
            string query = $"SELECT * FROM Events WHERE Id = {id}";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.QuerySingle<Events>(query);
            }
        }

        public void AddNewEvent(Events eventEntry)
        {
            string query = "INSERT INTO Events (Event, Location, Date) " +
                           "VALUES (@Event, @Location, @Date)";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, eventEntry);
            }
        }

        public void UpdateEvent(Events eventEntry)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "UPDATE Events " +
                           "SET Event=@Event, Location=@Location, Date=@Date " +
                           "WHERE Id = @Id";

            

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, eventEntry);
            }

          



        }

    


        public void DeleteEvent(int id)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "DELETE FROM Events " +
                          $"WHERE Id = {id}";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query);
            }
        }

        #endregion

        #region Games

        public List<Games> GetAllGames()
        {
            //The SQL Query to be sent to the database with request
            string query = "SELECT * FROM Games";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.Query<Games>(query).ToList();
            }
        }

        public Games GetGameById(int id)
        {
            //The SQL Query to be sent to the database with request
            string query = $"SELECT * FROM Games WHERE Id = {id}";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.QuerySingle<Games>(query);
            }
        }

        public void AddNewGame(Games gameEntry)
        {
            string query = "INSERT INTO Games (Game, Type) " +
                           "VALUES (@Game, @Type)";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, gameEntry);
            }
        }

        public void UpdateGame(Games gameEntry)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "UPDATE Games " +
                           "SET Game=@Game, Type=@Type " +
                           "WHERE Id=@Id";



            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, gameEntry);
            }


        }

        public void DeleteGame(int id)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "DELETE FROM Games " +
                           $"WHERE Id = {id}";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query);
            }
        }

        #endregion

        #region Results

        public List<ResultView> GetAllResults()
        {
            //The SQL Query to be sent to the database with request
            string query = "SELECT Results.Id, Events.Event AS Event, Games.Game AS Game, Team1.Team AS Team, Team2.Team AS OpTeam, Results.Result " +
                            "FROM Results " +
                            "INNER JOIN " +
                            "Events ON Events.Id = Results.EventId " +
                            "INNER JOIN " +
                            "Games ON Games.Id = Results.GameId " +
                            "INNER JOIN " +
                            "Teams AS Team1 ON Team1.Id = Results.TeamId " +
                            "INNER JOIN " +
                            "Teams AS Team2 ON Team2.Id = Results.OpTeamId " +
                            "ORDER BY Results.Id";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.Query<ResultView>(query).ToList();
            }
        }

        public Results GetResultById(int id)
        {
            //The SQL Query to be sent to the database with request
            string query = $"SELECT * FROM Results WHERE Id = {id}";

            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Request to be sent to the database
                return connection.QuerySingle<Results>(query);
            }
        }

        public void AddNewResult(Results resultEntry)
        {
            string query = "INSERT INTO Results (EventId, GameId, TeamId, OpTeamId, Result) " +
                           "VALUES (@EventId, @GameId, @TeamId, @OpTeamId, @Result)";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, resultEntry);
            }
        }

        public void UpdateResult(Results resultEntry)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "UPDATE Results " +
                           "SET EventId=@EventId, GameId=@GameId, TeamId=@TeamId, OpTeamId=@OpTeamId, Result=@Result " +
                           "WHERE Id=@Id";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query, resultEntry);
            }
        }

        public void DeleteResult(int id)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "DELETE FROM Results " +
                          $"WHERE Id = {id}";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query);
            }
        }

        public void UpdatePoints(int teamId, int points)
        {
            //The SQL Query to be sent to the database with our request.
            string query = "UPDATE Teams " +
                           $"SET Points = {points} " +
                           $"WHERE Id = '{teamId}'";

            // A using statement to manage the connection resource(object) which will dispose
            // of the resource once it is finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                // Request to be sent to the database.
                connection.Execute(query);
            }
        }

        #endregion

        #region Reports

        #endregion
    }
}
