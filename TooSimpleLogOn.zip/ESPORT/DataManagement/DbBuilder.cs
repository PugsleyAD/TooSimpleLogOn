﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using DataManagement.Models;

namespace DataManagement
{
    /// <summary>
    /// Database building class to programatically build the application database, tables and testing data.
    /// Inherits form the DataAdapter class to allow usage of some of its save methods.
    /// 
    /// This class is triggered from the App.xaml.cs constructor on startup.
    /// </summary>
    public class DbBuilder : DataAdapter
    {
        /// <summary>
        /// Sends a request to SQL Server to check if a databse exists matching name provided in the connection string. 
        /// If it does not exists the query then asks the
        /// server to create a new databse with the provided connection string name.
        /// </summary>
        public void CreateDatabase()
        {
            //Our connection object to link to the database
            SqlConnection connection = Helper.CreateSQLServerConnection("Default");
            try
            {
                //Custom connection string to only connect to the server layer of your SQL Database
                string connectionString = $"Data Source={connection.DataSource}; Integrated Security = True";
                //Query to build new Database if it does not already exist.
                string query = $"IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name ='{connection.Database}') " +
                $" CREATE DATABASE {connection.Database}";
                using (connection = new SqlConnection(connectionString))
                {
                    //A command object which will send our request to the Database <= Normally done for us by Dapper
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        //Checks if the connection is currently open, if not, it opens the connection.<= Normally done for us by Dapper
                        if (connection.State == ConnectionState.Closed)
                        {
                            connection.Open();
                        }
                        //Executes an SQL Request that does not expect a response(Query) to be returned.
                        command.ExecuteNonQuery();
                        //Closes the connection to the database manually.<= Normally done for us by Dapper
                        connection.Close();
                    }
                }
            }
            catch (Exception e)
            { 
            }
            
        }

        /// <summary>
        /// Runs a query against the database to get a count of how many base tables exist in the database.
        /// </summary>
        /// <returns>A confirmation of whther there are tables (TRUE) or not (FALSE)</returns>
        public bool DoTablesExist()
        {
            //Our using statemtnqwhich builds our connection and disposes of it once finished.
            using (var connection = Helper.CreateSQLServerConnection("Default"))
            {
                //Quey to request the count of how many base tables are in the database structure. Base tables refers to user
                //built tables and ignores inbuild tables such as index tables and reference/settings tables.
                string query = $"SELECT COUNT(*) FROM {connection.Database}.INFORMATION_SCHEMA.TABLES " +
                $"WHERE TABLE_TYPE = 'BASE TABLE'";
                //Sends the query to the databse and stores the returned table count.
                int count = connection.QuerySingle<int>(query);
                //If the count is above 0 return true, otherwise return false to indicate whether the databse has tabes or not.
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Method to send a request to the databse to create a new databse table. This method requires the table 
        /// name and column/attributes details to be pre-populated and
        /// passed to the method for it to work.
        /// </summary>
        /// <param name="name">The name to be given to the table when created.</param>
        /// <param name="structure">A string oulining all the table column/attributes and their names, 
        ///                         types and any other special rules for each of them such as PK
        /// identification, nullability rules and foreighn key connections.</param>
        private void CreateTable(string name, string structure)
        {
            try
            {
                //Partial query to build table in database. Parameters passe to method will be inserted to complete the query string.
                string query = $"CREATE TABLE {name} ({structure})";
                //Our using statemtnqwhich builds our connection and disposes of it once finished.
                using (var connection = Helper.CreateSQLServerConnection("Default"))
                {
                    //Passes the query to the databse to be perfomed.
                    connection.Execute(query);
                }
            }
            catch (Exception e)
            {
                //Log error on failure
            }
        }

        /// <summary>
        /// Triggers the database table creation and database seeding methods in the correct sequence to 
        /// ensure they are all generated properly and to avoid foreign key errors which can be caused by builkding or
        /// seeding the tables with foreign keys before the referenced tables or data have been built.
        /// </summary>
        public void BuildDatabaseTables()
        {
            BuildTeamsTable();
            BuildEventsTable();
            BuildGamesTable();
            BuildResultsTable();
            BuildUsersTable();

            SeedTeamsTable();
            SeedEventsTable();
            SeedGamesTable();
            SeedResultsTable();
            SeedUsersTable();
        }

        private void BuildUsersTable()
        {
            //Defines the column names and attributes for the table
            string structure = "Id int PRIMARY KEY IDENTITY(1,1), " +
                               "UserName VARCHAR(20) NOT NULL, " +
                               "Password VARCHAR(20), " +
                               "Role VARCHAR(10)";

            CreateTable("Users", structure);
        }

        private void SeedUsersTable()
        {
            //Create list to hold entriews that are being added.
            List<Users> user = new List<Users>();
            //Add new entries to list and provide them with sample data.
            user.Add(new Users
            {
                Id = 1,
                UserName = "admin",
                Password = "admin",
                Role = "ADMIN"
            });
            user.Add(new Users
            {
                Id = 2,
                UserName = "view",
                Password = "view",
                Role = "VIEWONLY"
            });
            //Iterate through the list and pass each entry to the addd method to send it to the database.
            foreach (var u in user)
            {
                AddUser(u);
            }
        }


        private void BuildTeamsTable()
        {
            //Defines the column names and attributes for the table
            string structure = "Id int PRIMARY KEY IDENTITY(1,1), " +
                               "Team VARCHAR(20) NOT NULL, " +
                               "Contact VARCHAR(20), " +
                               "Phone VARCHAR(20), " +
                               "Email VARCHAR(20), " +
                               "Points int";

            CreateTable("Teams", structure);
        }


        private void BuildEventsTable()
        {
            //Defines the column names and attributes for the table
            string structure = "Id int PRIMARY KEY IDENTITY(1,1), " +
                               "Event VARCHAR(20) NOT NULL, " +
                               "Location VARCHAR(20), " +
                               "Date date";

            CreateTable("Events", structure);
        }


        private void BuildGamesTable()
        {
            //Defines the column names, attributes and foreign keys for the table
            string structure = "Id int PRIMARY KEY IDENTITY(1,1), " +
                               "Game VARCHAR(20) NOT NULL, " +
                               "Type VARCHAR(10)";

            CreateTable("Games", structure);
        }

        private void BuildResultsTable()
        {
            //Defines the column names, attributes and foreign keys for the table
            string structure = "Id int PRIMARY KEY IDENTITY(1,1), " +
                               "EventId int NOT NULL, " +
                               "GameId int NOT NULL, " +
                               "TeamId int NOT NULL, " +
                               "OpTeamId int NOT NULL, " +
                               "Result VARCHAR(10) NOT NULL " +
                               "FOREIGN KEY (EventId) REFERENCES Events(Id), " +
                               "FOREIGN KEY (GameId) REFERENCES Games(Id), " +
                               "FOREIGN KEY (TeamId) REFERENCES Teams(Id), " +
                               "FOREIGN KEY (OpTeamId) REFERENCES Teams(Id)";

            CreateTable("Results", structure);
        }


        private void SeedTeamsTable()
        {
            //Create list to hold entriews that are being added.
            List<Teams> team = new List<Teams>();
            //Add new entries to list and provide them with sample data.
            team.Add(new Teams
            {
                Id = 1,
                Team = "Tm_001",
                Contact = "Troy Vaughn",
                Phone = "04123",
                Email = "TV@email",
                Points = 100

            });
            team.Add(new Teams
            {
                Id = 2,
                Team = "Tm_002",
                Contact = "Jane Lane",
                Phone = "04123",
                Email = "JL@email",
                Points = 89
            });
            team.Add(new Teams
            {
                Id = 3,
                Team = "Tm_003",
                Contact = "Gary Barlow",
                Phone = "04123",
                Email = "GB@email",
                Points = 77
            });
            //Iterate through the list and pass each entry to the addd method to send it to the database.
            foreach (var t in team)
            {
                AddNewTeam(t);
            }
        }

        private void SeedEventsTable()
        {
            //Create list to hold entriews that are being added.
            List<Events> eve = new List<Events>();
            //Add new entries to list and provide them with sample data.
            eve.Add(new Events
            {
                Id = 1,
                Event = "EV_001",
                Location = "Brisbane",
                Date = DateTime.Parse("2023-11-22")
            });
            eve.Add(new Events
            {
                Id = 2,
                Event = "EV_002",
                Location = "Sydney",
                Date = DateTime.Parse("2023-10-27")

            });
            eve.Add(new Events
            {
                Id = 3,
                Event = "EV_003",
                Location = "Brisbane",
                Date = DateTime.Parse("2023-01-08")

            });
            //Iterate through the list and pass each entry to the addd method to send it to the database.
            foreach (var e in eve)
            {
                AddNewEvent(e);
            }
        }

        private void SeedGamesTable()
        {
            //Create list to hold entriews that are being added.
            List<Games> game = new List<Games>();
            //Add new entries to list and provide them with sample data.
            game.Add(new Games
            {
                Id = 1,
                Game = "NBA",
                Type = "Team",

            });
            game.Add(new Games
            {
                Id = 2,
                Game = "UFC",
                Type = "Solo",

            });
            game.Add(new Games
            {
                Id = 3,
                Game = "FIFA",
                Type = "Team",

            });
            //Iterate through the list and pass each entry to the addd method to send it to the database.
            foreach (var g in game)
            {
                AddNewGame(g);
            }
        }

        private void SeedResultsTable()
        {
            //Create list to hold entriews that are being added.
            List<Results> result = new List<Results>();
            //Add new entries to list and provide them with sample data.
            result.Add(new Results
            {
                Id = 1,
                EventId = 1,
                GameId = 2,
                TeamId = 3,
                OpTeamId = 1,
                Result = "Win"

            });
            result.Add(new Results
            {
                Id = 2,
                EventId = 2,
                GameId = 3,
                TeamId = 1,
                OpTeamId = 2,
                Result = "Draw"

            });
            result.Add(new Results
            {
                Id = 3,
                EventId = 3,
                GameId = 1,
                TeamId = 2,
                OpTeamId = 3,
                Result = "Loss"

            });
            //Iterate through the list and pass each entry to the addd method to send it to the database.
            foreach (var r in result)
            {
                AddNewResult(r);
            }
        }
    }


}