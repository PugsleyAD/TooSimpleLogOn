﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement.Models
{
    public class Games
    {
        public int Id { get; set; }
        public string Game { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;

        public Games() { }

        public Games(int id, string game, string type)
        {
            Id = id;
            Game = game;
            Type = type;
        }

        public override string ToString()
        {
            return $"{Id},{Game},{Type}";
        }
    }
}
