﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DataManagement.Models
{
    public class Teams
    {
        public int Id { get; set; }
        public string Team { get; set; } = string.Empty;
        public string Contact { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public int Points { get; set; }


        public Teams() { }

        public Teams(int id, string team, string contact, string phone, string email, int points)
        {
            Id = id;
            Team = team;
            Contact = contact;
            Phone = phone;
            Email = email;
            Points = points;
        }

        public override string ToString()
        {
            return $"{Id},{Team},{Contact},{Phone},{Email},{Points}";
        }
    }
}
