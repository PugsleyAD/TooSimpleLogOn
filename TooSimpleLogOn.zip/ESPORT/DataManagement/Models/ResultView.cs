﻿using System.Diagnostics.Contracts;

namespace DataManagement.Models
{
    public class ResultView
    {
        public int Id { get; set; }
        public string Event { get; set; } = string.Empty;
        public string Game { get; set; } = string.Empty;
        public string Team { get; set; } = string.Empty;
        public string OpTeam { get; set; } = string.Empty;
        public string Result { get; set; } = string.Empty;


        public ResultView() { }

        public ResultView(int id, string eve, string game, string team, string opTeam, string result)
        {
            Id = id;
            Event = eve;
            Game = game;
            Team = team;
            OpTeam = opTeam;
            Result = result;
        }


        //Overrides the default toString implementation to output the desired comma separated value string when called.
        public override string ToString()
        {
            return $"{Id},{Event},{Game},{Team},{OpTeam},{Result}";
        }
    }
}
