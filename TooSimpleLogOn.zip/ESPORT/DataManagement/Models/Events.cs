﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement.Models
{
    public class Events
    {
        public int Id { get; set; }
        public string Event { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public DateTime Date { get; set; }

        public Events() { }

        public Events(int id, string eve, string location, DateTime date)//  'event' is reserved
        {
            Id = id;
            Event = eve;
            Location = location;
            Date = date;
        }
        public override string ToString()
        {
            return $"{Id},{Event},{Location},{Date}";
        }
    }

}
