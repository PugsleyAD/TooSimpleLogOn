﻿using System.Diagnostics.Contracts;

namespace DataManagement.Models
{
    public class Results
    {
        public int Id { get; set; }
        public int EventId { get; set; }
        public int GameId { get; set; }
        public int TeamId { get; set; }
        public int OpTeamId { get; set; }
        public string Result { get; set; }


        public Results() { }

        public Results(int id, int eventId, int gameId, int teamId, int opTeamId, string result)
        {
            Id = id;
            EventId = eventId;
            GameId = gameId;
            TeamId = teamId;
            OpTeamId = opTeamId;
            Result = result;
        }

    }
}
