﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement.Models
{
    public class Users
    {
        public int Id { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Role { get; set; } = "VIEWONLY";

        public Users() { }

        public Users(int id, string userName, string password, string role)
        {
            Id = id;
            UserName = userName;
            Password = password;
            Role = role;
        }

        public override string ToString()
        {
            return $"{Id},{UserName},{Password},{Role}";
        }
    }
}
